GMH Example
Version 1.3

This is a example built to allow online highscores.

Visit www.gmhighscores.com if you haven't signed up for this service.

Netread.dll created by Roach: http://gmc.yoyogames.com/index.php?showuser=3850